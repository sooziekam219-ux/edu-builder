const view_pageinfo = [{ url: "view01" }, { url: "view02" }];
